#pragma once
#include"Interface.h"
struct Ranking
{
	int m_iStage;
	string m_strName;
	int m_iScore;
};
class Rank
{
private:
	vector<Ranking> m_vRank;
	Interface m_UI;
	UtilTool m_Tool;
	const string m_strFile = "Rank.txt";
public:
	void RankLoad();
	void Save(string Name,int Score,int Stage);
	void RankShow();
	Rank();
	~Rank();
};

