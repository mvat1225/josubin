#pragma once
#include"UtilTool.h"
class Ward
{
protected:
	int m_iItem;
	UtilTool m_Tool;
	string m_strWord;
	int m_ix;
	int m_iy;
public:
	Ward();
	Ward(string ward, int x, int itemtype);
	inline int GetItem() { return m_iItem; };
	inline string GetWard() { return m_strWord; };
	inline int GetX() { return m_ix; };
	inline int GetY() { return m_iy; };
	void Hidden();
	void Draw();
	void Drop();
	void Die();
	~Ward();
};

