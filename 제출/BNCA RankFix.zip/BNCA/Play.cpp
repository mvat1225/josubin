#include "Play.h"
Play::Play()
{
	m_bPenalty = false;//////////////////////
	m_iStage = 1;
	m_bGameEnd = false;
	P1.iHealth = 9;
	P1.iScore = 0;
	P1.strName = "";
	m_bWardReturn = false;
	m_iSpeed = DIFFICULT_EASY;
}
void Play::Input()
{
	m_iSpeed = DIFFICULT_EASY;
	m_bPenalty = false;
	m_bWardReturn = false;
	m_iStage = 1;
	m_bGameEnd = false;
	P1.iHealth = 9;
	P1.iScore = 0;
	P1.strName = "";
	W_Manager.ClearWard();
	W_Manager.ResetItem();
}
bool Play::RandPercent()
{
	return true;
	int num;
	if (DIFFICULT_NOMAL < m_iSpeed && m_iSpeed <= DIFFICULT_EASY)
		num = rand() % 4;
	else if (DIFFICULT_HARD < m_iSpeed && m_iSpeed <= DIFFICULT_NOMAL)
		num = rand() % 3;
	else
		num = rand() % 2;
	if (num == 0)
		return true;
	else
		return false;
}
void Play::GetName()
{
	m_Tool.DrawMidText("�г��� �Է�", MAP_WIDTH, MAP_HEIGHT - 8);
	while (1)
	{
		string tmp;
		char ch_tmp = getch();
		if (ch_tmp == ENTER)
			return;
		else if (ch_tmp == BACKSPACE && P1.strName.size() > 0)
		{
			if(P1.strName.size() >= 10)
				m_Tool.DrawMidText("                  ", MAP_WIDTH, MAP_HEIGHT - 8);
			int lenth = P1.strName.size() - 1;
			P1.strName = P1.strName.substr(0, lenth);
			m_Tool.DrawMidText("               ", MAP_WIDTH, MAP_HEIGHT - 5);
		}
		else if (P1.strName.size() >= 10)
		{
			UI.DrawWardCountOver(10);
		}
		else if (ch_tmp >= 'a' && ch_tmp <= 'z')
		{
			tmp += ch_tmp;
			P1.strName += tmp;
		}
		m_Tool.DrawMidText(P1.strName, MAP_WIDTH, MAP_HEIGHT - 5);
	}
}
void Play::GetWard()
{
	cin.clear();
	m_Tool.DrawMidText("                 ", MAP_WIDTH, MAP_HEIGHT - 8);
	string tmp;
	char ch_tmp = getch();
	if (ch_tmp == ENTER)
	{
		m_bWardReturn = true;
		m_Tool.DrawMidText("                 ", MAP_WIDTH, MAP_HEIGHT - 8);
	}
	else if (ch_tmp == BACKSPACE && m_strEnterWard.size() > 0)
	{
		if (m_strEnterWard.size() == 20)
		{
			m_Tool.DrawMidText("                  ", MAP_WIDTH, MAP_HEIGHT - 8);
		}
		int lenth = m_strEnterWard.size() - 1;
		m_strEnterWard = m_strEnterWard.substr(0, lenth);
		m_Tool.DrawMidText("                     ", MAP_WIDTH, MAP_HEIGHT - 5);
	}
	else if (m_strEnterWard.size() >= 20)
	{
		UI.DrawWardCountOver(20);
	}
	else if (ch_tmp >= 'a' && ch_tmp <= 'z')
	{
		tmp += ch_tmp;
		m_strEnterWard += tmp;
	}
	ORIGINAL
	m_Tool.DrawMidText(m_strEnterWard, MAP_WIDTH, MAP_HEIGHT - 5);
}

void Play::StageUp()
{
	m_iStage++;
	UI.PrintStage(m_iStage);
	P1.iScore = 0;
	W_Manager.ClearWard();
	m_Tool.ClearBox(MAP_WIDTH, MAP_HEIGHT);
	UI.PrintInputBox();
	UI.PrintScore(P1.iScore);
	if(m_iSpeed>=50)
		m_iSpeed -= 50;
}
void Play::InGame()
{
	int ResetClock = 0;
	int PenaltyResetClock=0;
	int NowClock;
	NowClock = clock();
	UI.PrintStage(m_iStage);
	m_Tool.ClearBox(MAP_WIDTH, MAP_HEIGHT);
	UI.PrintInputBox();
	while (1)
	{
		ResetClock = clock();
		if (kbhit() && !m_bPenalty)
			GetWard();
		if (m_bWardReturn)
		{
			if (1 == W_Manager.CompareWard(m_strEnterWard))
			{
				P1.iScore++;
				UI.PrintScore(P1.iScore);
			}
			else
			{
				
				m_bPenalty = true;
				m_bWardReturn = false;
			}
			m_strEnterWard = "";
			m_bWardReturn = false;
		}
		if (m_bPenalty && PenaltyResetClock == 0)
			PenaltyResetClock = clock();
		if ((ResetClock - PenaltyResetClock >= 3000) && m_bPenalty)
		{
			m_bPenalty = false;//////////////////////////
			m_Tool.DrawMidText("                 ", MAP_WIDTH, MAP_HEIGHT - 8);
			PenaltyResetClock = 0;
		}
	
		if (P1.iScore % 5 == 0 && P1.iScore > 0)
		{
			StageUp();
		}
		if (W_Manager.DeadCheck())
		{
			P1.iHealth--;
			UI.PrintHealthBar(P1.iHealth);
		}
		W_Manager.MoveWards(NowClock, ResetClock, m_iSpeed, RandPercent());
		if (P1.iHealth == 0)
		{
			UI.PrintGameOver();
			m_bGameEnd = true;
			break;
		}
	}
}
void Play::GetPlayerName()
{
	UI.GetNameUI();
	GetName();
	m_Tool.ClearBox(MAP_WIDTH, MAP_HEIGHT);
}
void Play::PlayGame()
{
	while (1)
	{
		switch (UI.StartMenu(P1))
		{
		case GAMESTART:
			Input();
			UI.PrintStory();
			GetPlayerName();
			UI.PrintUnderUI(P1);
			while (!m_bGameEnd)
			{
				InGame();
			}
			m_Rank.Save(P1.strName, P1.iScore, m_iStage);
			break;
		case RANKING:
			m_Rank.RankShow();
			break;
		case END:
			break;
		}
	}
}
Play::~Play()
{

}