#include "Interface.h"
Interface::Interface()
{
}
void Interface::GetNameUI()
{
	m_DrawTool.ClearBox(m_stMap.m_iWidth, m_stMap.m_iHeight);
	PrintInputBox();
	m_DrawTool.gotoxy(m_stMap.m_iWidth, m_stMap.m_iHeight - 5);
}
bool Interface::StorySkipCheck()
{
	if (kbhit())
	{
		char ch = getch();
		if (ch == SKIP)
			return true;
		else
			return false;
	}
}
void Interface::PrintGameOver()
{
	RED
	system("cls");
	m_DrawTool.BoxDraw(MAP_WIDTH, MAP_HEIGHT);
	m_DrawTool.DrawMidText(": : :GAME OVER: : :", MAP_WIDTH, MAP_HEIGHT * 0.5);
	ORIGINAL
}
void Interface::PrintStory()
{
	bool End = false;
	int OldClock, ResetClock;
	int StartNum = 0, EndNum = 10;
	int y = 8;
	int Count = 1;
	m_DrawTool.ClearBox(m_stMap.m_iWidth, m_stMap.m_iHeight);
	vector<string> Story;
	string tmp;
	ifstream LoadStory;
	LoadStory.open(m_strStoryFile);
	if (LoadStory.is_open())
	{
		while (!LoadStory.eof())
		{
			getline(LoadStory, tmp);
			Story.push_back(tmp);
		}
		LoadStory.close();
	}
	else
	{
		cout << "���丮 ������ ���� �Ǿ����ϴ� . . . ";
		return;
	}
	PrintInputBox();
	m_DrawTool.DrawMidText("SKIP : 's'", m_stMap.m_iWidth, m_stMap.m_iHeight - 5);
	OldClock = clock();
	while (!End)
	{
		End = StorySkipCheck();
		ResetClock = clock();
		if (ResetClock - OldClock >= 1000)
		{
			if (Count < 10)
			{
				m_DrawTool.DrawMidText(Story[Count-1], m_stMap.m_iWidth, y);
				y++;
				Count++;
				OldClock = ResetClock;
			}
			else
			{
				y = 8;
				for (int i = StartNum; i < EndNum; i++)
				{
					m_DrawTool.DrawMidText("                                            ", m_stMap.m_iWidth, y);
					m_DrawTool.DrawMidText(Story[i], m_stMap.m_iWidth, y);
					y++;
					OldClock = ResetClock;
				}
				y = 8;
				StartNum++;
				EndNum++;
				if (EndNum > Story.size())
					End = true;
			}
		}
	}
}
void Interface::PrintStage(int Stage)
{
	m_DrawTool.ClearBox(m_stMap.m_iWidth, m_stMap.m_iHeight);
	m_DrawTool.DrawMidText("STAGE " + to_string(Stage), MAP_WIDTH, MAP_HEIGHT * 0.5);
	int CurClock, OldClock;
	OldClock = clock();
	while (1)
	{
		CurClock = clock();
		if (CurClock - OldClock > 1200)
		{
			return;
		}
	}
}
void Interface::DrawWardCountOver(int Num)
{
	m_DrawTool.DrawMidText(to_string(Num) + "�ܾ� �ʰ�! ! !", MAP_WIDTH, MAP_HEIGHT - 8);
}
void Interface::PrintInputBox()
{
	m_DrawTool.DrawMidText("                                      ", m_stMap.m_iWidth, m_stMap.m_iHeight - 7);
	m_DrawTool.DrawMidText("��������������������������������������", m_stMap.m_iWidth, m_stMap.m_iHeight -7);
	m_DrawTool.DrawMidText("��                                  ��", m_stMap.m_iWidth, m_stMap.m_iHeight - 6);
	m_DrawTool.DrawMidText("��                                  ��", m_stMap.m_iWidth, m_stMap.m_iHeight - 5);
	m_DrawTool.DrawMidText("��                                  ��", m_stMap.m_iWidth, m_stMap.m_iHeight - 4);
	m_DrawTool.DrawMidText("��������������������������������������", m_stMap.m_iWidth, m_stMap.m_iHeight - 3);
}
void Interface::PrintScore(int Score)
{
	GOLD
	m_DrawTool.DrawMidText("  Score : " + to_string(Score)+"  ", m_stMap.m_iWidth, m_stMap.m_iHeight + 2);
	ORIGINAL
}
void Interface::PrintName(string Name)
{
	GOLD
	if(Name == "")
		m_DrawTool.Draw_Text("Name : ? ? ? ?", m_stMap.m_iWidth * 1.6, m_stMap.m_iHeight + 2);
	else
	{
		m_DrawTool.Draw_Text("                    " , m_stMap.m_iWidth * 1.6, m_stMap.m_iHeight + 2);
		m_DrawTool.Draw_Text("Name : " + Name, m_stMap.m_iWidth * 1.6, m_stMap.m_iHeight + 2);
	}
	ORIGINAL	
}
void Interface::PrintRankBox()
{
	system("cls");
	string line;
	m_DrawTool.BoxDraw(MAP_WIDTH, MAP_HEIGHT);
	m_DrawTool.DrawMidText("��������������������������������", MAP_WIDTH, 0 + 3);
	m_DrawTool.DrawMidText("��                            ��", MAP_WIDTH, 0 + 4);
	m_DrawTool.DrawMidText("��                            ��", MAP_WIDTH, 0 + 5);
	m_DrawTool.DrawMidText("RANKING", MAP_WIDTH, 0 + 5);
	m_DrawTool.DrawMidText("��                            ��", MAP_WIDTH, 0 + 6);
	m_DrawTool.DrawMidText("��������������������������������", MAP_WIDTH, 0 + 7);
	for (int i = 3; i < MAP_WIDTH*2 - 3; i++)
	{
		line += "=";
	}
	m_DrawTool.DrawMidText(line, MAP_WIDTH, 0 + 8);
	m_DrawTool.DrawMidText("Name             Score             Stage", MAP_WIDTH, 0 + 10);
}
void Interface::PrintHealthBar(int Health)
{
	GOLD
	string HealthBar = "Life : ";
	for (int i = 0; i < Health; i++)
	{
		HealthBar += "��";
	}
	m_DrawTool.Draw_Text(HealthBar+"   ", m_stMap.m_iWidth * 0.1, m_stMap.m_iHeight + 2);
	ORIGINAL
}
void Interface::PrintUnderUI(Player Playerinfo)
{
	PrintName(Playerinfo.strName);
	PrintScore(Playerinfo.iScore);
	PrintHealthBar(Playerinfo.iHealth);
}
int Interface::StartMenu(Player PlayerInfo)
{
	int select;
	m_DrawTool.SetConsole(m_stMap.m_iWidth, m_stMap.m_iHeight);
	m_DrawTool.BoxDraw(m_stMap.m_iWidth, m_stMap.m_iHeight);
	m_DrawTool.DrawMidText("�� �� �� �� �� �� ġ �� �� �� �� ��", m_stMap.m_iWidth, m_stMap.m_iHeight * 0.3);
	m_DrawTool.DrawMidText("1.Game Start", m_stMap.m_iWidth, m_stMap.m_iHeight * 0.5 - 2);
	m_DrawTool.DrawMidText("2.Rank", m_stMap.m_iWidth, m_stMap.m_iHeight * 0.5);
	m_DrawTool.DrawMidText("3.Exit", m_stMap.m_iWidth, m_stMap.m_iHeight * 0.5 + 2);
	PrintUnderUI(PlayerInfo);
	select = 	m_DrawTool.SelectCursor(2, 3, m_stMap.m_iWidth*0.8, m_stMap.m_iHeight * 0.5 - 2);
	return select;
}
Interface::~Interface()
{

}