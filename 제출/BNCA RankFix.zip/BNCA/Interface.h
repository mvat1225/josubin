#pragma once
#include"UtilTool.h"
struct Map {
	int m_iWidth = MAP_WIDTH;
	int m_iHeight = MAP_HEIGHT;
};
class Interface
{
private:
	const string m_strStoryFile = "����ġ��_���丮.txt";
	UtilTool m_DrawTool;
	const Map m_stMap;
public:
	void PrintGameOver();
	void PrintRankBox();
	void PrintStage(int Stage);
	void DrawWardCountOver(int Num);
	void PrintUnderUI(Player Playerinfo);
	void GetNameUI();
	bool StorySkipCheck();
	void PrintStory();
	void PrintInputBox();
	void PrintName(string Name);
	void PrintScore(int Score);
	void PrintHealthBar(int Health);
	int StartMenu(Player PlayerInfo);
	Interface();
	~Interface();
};

