#include "WordManager.h"
WordManager::WordManager()
{
	ifstream WordFile;
	string Wardstr;
	WordFile.open(m_strWordFile);
	if (WordFile.is_open())
	{
		while (!WordFile.eof())
		{
			getline(WordFile, Wardstr);
			Ward tmp(Wardstr, 0, 0);
			m_vWard.push_back(tmp);
		}
		WordFile.close();
	}
	else
	{
		cout << "���� ������ ���� �Ǿ����ϴ� . . .";
		system("pause");
		return;
	}
	m_strEnterWard = "";
	m_bWardReturn = false;
	m_bSpeedUp = false;
	m_bSpeedDown = false;
	m_bStop = false;
	m_bHidden = false;
}
void WordManager::ResetItem()
{
	m_bWardReturn = false;
	m_bSpeedUp = false;
	m_bSpeedDown = false;
	m_bStop = false;
	m_bHidden = false;
}
void WordManager::ClearWard()
{
	for (auto iter = m_vInGameWardList.begin(); iter != m_vInGameWardList.end(); iter++)
	{
		(*iter)->Die();
	}
	m_vInGameWardList.clear();
	UI_Tool.PrintInputBox();
}
void WordManager::DrawWards()
{
	for (int i = 0; i < m_vInGameWardList.size(); i++)
	{
		m_vInGameWardList[i]->Draw();
	}
}


int WordManager::CompareWard(string ward)
{
	m_bWardReturn = false;
	if (KillWard(ward))
	{
		m_Tool.DrawMidText("               ", MAP_WIDTH, MAP_HEIGHT - 5);
		return 1;
	}
	else
	{
		m_Tool.DrawMidText("Ʋ�� ! �г�Ƽ !", MAP_WIDTH, MAP_HEIGHT - 8);
	}
	m_strEnterWard = "";
	m_Tool.DrawMidText("               ", MAP_WIDTH, MAP_HEIGHT - 5);
	return -1;
}
void WordManager::MoveWards(int& NowClock, int& ResetClock, int& SPeed,bool bMakeWard)
{
	/// ////////////////////////////////////////////////////////////////////////////////////
	if (m_bSpeedUp && SpeedUpClock == 0)
	{
		SPeed -= 300;
		SpeedUpClock = clock();
	}
	if ((ResetClock - SpeedUpClock >= GrantClock) && m_bSpeedUp)
	{
		SPeed += 300;
		m_bSpeedUp = false;
		SpeedUpClock = 0;
	}
	/// ////////////////////////////////////////////////////////////////////////////////////
	if (m_bSpeedDown && SpeedDownClock == 0)
	{
		SPeed += 300;
		SpeedDownClock = clock();
	}
	if ((ResetClock - SpeedDownClock >= GrantClock) && m_bSpeedDown)
	{
		SPeed -= 300;
		m_bSpeedDown = false;
		SpeedDownClock = 0;
	}
	/// ////////////////////////////////////////////////////////////////////////////////////
	if (m_bHidden && HiddenClock == 0)
	{
		HiddenClock = clock();
	}
	if ((ResetClock - HiddenClock >= GrantClock) && m_bHidden)//������
	{
		m_bHidden = false;
		HiddenClock = 0;
	}
	/// ////////////////////////////////////////////////////////////////////////////////////
	if (m_bStop && PauseClock == 0)
	{
		PauseClock = clock();
	}
	if ((ResetClock - PauseClock >= GrantClock) && m_bStop)
	{
		m_bStop = false;
		PauseClock = 0;
	}
	/// ////////////////////////////////////////////////////////////////////////////////////
	if (ResetClock - NowClock >= SPeed)
	{
		for (int i = 0; i < m_vInGameWardList.size(); i++)
		{
			if (!m_bStop)
				m_vInGameWardList[i]->Drop();
		}
		if (bMakeWard && !m_bStop)
			MakeWard();
		if (m_bHidden)
		{
			HiddenWard();
		}
		else
			DrawWards();
		NowClock = ResetClock;
	}
}
void WordManager::HiddenWard()
{
	for (auto iter = m_vInGameWardList.begin(); iter != m_vInGameWardList.end(); iter++)
	{
		(*iter)->Hidden();
	}
}
bool WordManager::KillWard(string _Word)
{
	for (auto iter = m_vInGameWardList.begin(); iter != m_vInGameWardList.end(); iter++)
	{
		if ((*iter)->GetWard() == _Word)
		{
			(*iter)->Die();
			switch ((*iter)->GetItem())
			{
			case ITEM_SPEEDUP:
				m_bSpeedUp = true;
				break;
			case ITEM_SPEEDDOWN:
				m_bSpeedDown = true;
				break;
			case ITEM_ALLCLEAR:
				ClearWard();
				return true;
			case ITEM_PAUSE:
				m_bStop = true;
				break;
			case ITEM_HIDDEN:
				m_bHidden = true;
				break;
			}
			m_vInGameWardList.erase(iter);
			return true;
		}
	}
	return 0;
}
int WordManager::DeadCheck()
{
	for (auto iter = m_vInGameWardList.begin(); iter != m_vInGameWardList.end(); iter++)///////////����
	{
		if ((*iter)->GetY() == MAP_HEIGHT - 1)
		{
			m_vInGameWardList.erase(iter);
			return 1;
		}
	}
	return 0;
}
void WordManager::MakeWard()
{
	int RandNum = rand() % m_vWard.size();
	int Item = rand() % 6;
	Ward* tmp = new Ward(m_vWard[RandNum].GetWard(), GetRandX(), Item);
	m_vInGameWardList.push_back(tmp);
}
int WordManager::GetRandX()
{
	while(1)
	{
		int x = rand() % MAP_WIDTH * 1.7;
		if (x > 2)
			return x;
	}
}
WordManager::~WordManager()
{

}