#pragma once
#include"Interface.h"
#include"WordManager.h"
#include"Rank.h"
class Play
{
private:
	Rank m_Rank;
	WordManager W_Manager;
	Player P1;
	Interface UI;
	UtilTool m_Tool;
	bool m_bGameEnd;
	bool m_bWardReturn;
	string m_strEnterWard;
	int m_iStage;
	bool m_bPenalty;
	int m_iSpeed;
public:
	bool RandPercent();
	void GetWard();
	void Input();
	void StageUp();
	void GetName();
	void InGame();
	void GetPlayerName();
	void PlayGame();
	Play();
	~Play();
};

