#pragma once
#include"Ward.h"
#include"Interface.h"
class WordManager
{
private:
	UtilTool m_Tool;
	Interface UI_Tool;
	vector<Ward> m_vWard;
	vector<Ward*>m_vInGameWardList;
	bool m_bWardReturn;
	string m_strEnterWard;
	const string m_strWordFile = "Word.txt";
	bool m_bSpeedUp;
	bool m_bSpeedDown;
	bool m_bStop;
	bool m_bHidden;
	int SpeedDownClock = 0;
	int SpeedUpClock = 0;
	int PauseClock = 0;
	int HiddenClock = 0;
	int PenaltyResetClock = 0;
	int GrantClock = 3000;
public:
	void ResetItem();
	void HiddenWard();
	int CompareWard(string ward);
	void ClearWard();
	bool KillWard(string Word);
	int DeadCheck();
	void DrawWards();
	void MoveWards(int& NowClock, int& ResetClock, int& SPeed, bool bMakeWard);
	void MakeWard();
	int GetRandX();
	WordManager();
	~WordManager();
};

