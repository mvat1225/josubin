#include "Rank.h"
Rank::Rank()
{

}
void Rank::Save(string Name, int Score, int Stage)
{
	ofstream Save;
	Save.open(m_strFile, ios::app);
	if (Save.is_open())
	{
		Save << Name << " " << Score << " " << Stage;
	}
	Save.close();
}
void Rank::RankLoad()
{
	int Big;
	int score = 0;
	int inttmp=0;
	Ranking tmp;
	string trash;
	vector<Ranking>v_tmp;
	ifstream Load;
	Load.open(m_strFile);
	if (Load.is_open())
	{
		while (!Load.eof())
		{
			Load >> tmp.m_strName;
			Load >> tmp.m_iScore;
			Load >> tmp.m_iStage;
			v_tmp.push_back(tmp);
		}
	}
	Load.close();
	while (m_vRank.size() <= 8 && v_tmp.size() != 0)
	{
		for (int i = 0; i < v_tmp.size(); i++)
		{
			if (score <= (v_tmp[i].m_iScore + v_tmp[i].m_iStage * 20))
			{
				Big = i;
				score = v_tmp[i].m_iScore + v_tmp[i].m_iStage * 20;
			}	
		}
		m_vRank.push_back(v_tmp[Big]);
		int Count = 0;
		for (auto iter = v_tmp.begin(); iter != v_tmp.end(); iter++)
		{
			if (Count == Big)
			{
				v_tmp.erase(iter);
				break;
			}
			Count++;
		}
		score = 0;
	}
}
void Rank::RankShow()
{
	m_UI.PrintRankBox();
	RankLoad();
	int y = 11;
	for (auto iter = m_vRank.begin(); iter != m_vRank.end(); iter++)
	{
		m_Tool.DrawMidText(iter->m_strName + "                 " + to_string(iter->m_iScore) + "                 " + to_string(iter->m_iStage), MAP_WIDTH, y);
		y += 2;
	}
	getch();
	m_vRank.clear();
}
Rank::~Rank()
{

}