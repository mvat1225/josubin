#include "UtilTool.h"
UtilTool::UtilTool()
{
	
}
void UtilTool::ClearBox(int x, int y)
{
	string tmp;
	for (int x_ = 3; x_ < x * 2 - 4; x_++)
	{
		tmp += " ";
	}
	for (int y_ = 1; y_ < y-1; y_++)
	{
		gotoxy(3, y_);
		cout << tmp;
	}
}
void UtilTool::Draw_Text(string text, int x, int y)
{
	gotoxy(x, y);
	cout << text;
}
void UtilTool::DrawMidText(string text, int x, int y)
{
	x -= text.size() / 2;
	gotoxy(x, y);
	cout << text;
}
void UtilTool::BoxDraw(int _X, int _Y)
{
	for (int y = 0; y < _Y; y++)
	{
		for (int x = 0; x < _X; x++)
		{
			if (x == 0 && y == 0)
				cout << "��";
			else if (x == 0 && y == _Y - 1)
				cout << "��";
			else if (x == _X - 1 && y == 0)
				cout << "��";
			else if (x == _X - 1 && y == _Y - 1)
				cout << "��";
			else if (y == 0 || y == _Y - 1)
				cout << "��";
			else if (x == 0 || x == _X - 1)
				cout << "��";
			else
				cout << "  ";
		}
		cout << endl;
	}
}
void UtilTool::SetConsole(int x, int y)
{
	char tmp[256];
	sprintf(tmp, "mode con cols=%d lines=%d", x*2+1, y+4);
	system(tmp);
}
int UtilTool::SelectCursor(int cols, int Menucount, int start_x, int start_y)
{
	string cursor = "��";
	char key;
	int Select = 1;
	gotoxy(start_x, start_y);
	cout << cursor;
	while (1)
	{
		key = getch();
		switch (key)
		{
		case UP:
			if (Select > 1)
			{
				gotoxy(start_x, start_y);
				cout << "  ";
				start_y -= cols;
				Select--;
			}
			break;
		case DOWN:
			if (Select < Menucount)
			{
				gotoxy(start_x, start_y);
				cout << "  ";
				start_y += cols;
				Select++;
			}
			break;
		case ENTER:
			return Select;
		}
		gotoxy(start_x, start_y);
		cout << cursor;
	}
}
UtilTool::~UtilTool()
{

}