#include "Ward.h"
Ward::Ward()
{

}
void Ward::Die()
{
	m_Tool.gotoxy(m_ix, m_iy);
	for (int i = 0; i < m_strWord.length(); i++)
	{
		cout << " ";
	}
}
Ward::Ward(string ward, int x,int itemtype)
{
	m_strWord = ward;
	m_ix = x;
	m_iy = 1;
	m_iItem = itemtype;
	Draw();
}
void Ward::Drop()
{
	m_iy++;
}
void Ward::Draw()
{
	switch (m_iItem)
	{
	case ITEM_NOTING:
		ORIGINAL;
		break;
	case ITEM_SPEEDUP:
		RED
		break;
	case ITEM_SPEEDDOWN:
		GOLD
		break;
	case ITEM_ALLCLEAR:
		GRAY
		break;
	case ITEM_HIDDEN:
		HIGH_GREEN
		break;
	case ITEM_PAUSE:
		BLUE_GREEN
		break;
	}
	if (m_iy <= ROOF_END + 1 && m_iy >= ROOF_START &&
		(((m_strWord.size() + m_ix >= SIDE_START) && (m_ix < SIDE_START))
			|| (m_ix >= SIDE_START && m_ix <= SIDE_END)))
	{
		int length = 0;
		if (m_ix >= SIDE_START && m_ix + m_strWord.length() <= SIDE_END)
		{
			if (m_iy == ROOF_START)
			{
				m_Tool.gotoxy(m_ix, m_iy - 1);
				for (int i = 0; i < m_strWord.size(); i++)
					cout << " ";
			}
			return;
		}
		else if (m_ix <= SIDE_START)
		{
			while (!(length + m_ix >= SIDE_START-1))
			{
				m_Tool.gotoxy(m_ix, m_iy);
				
				length++;
			}
			if (m_iy == ROOF_END + 1)
			{
				cout << m_strWord;
			}
			else 
				cout << m_strWord.substr(0, length);
			m_Tool.gotoxy(m_ix, m_iy - 1);
			if (m_iy == ROOF_START && m_iy != ROOF_END + 1)
			{
				m_Tool.gotoxy(m_ix, m_iy - 1);
				for (int i = 0; i < m_strWord.size(); i++)
					cout << " ";
			}
			for (int i = 0; i < length; i++)
				cout << " ";
			return;
		}
		else if (m_ix < SIDE_END)
		{
			while (length + m_ix <= SIDE_END)
			{
				if (m_ix + m_strWord.length() < SIDE_END)
				{
					length = 0;
					break;
				}	
				length++;
			}
			if (m_iy == ROOF_END + 1)
			{
				m_Tool.gotoxy(m_ix, m_iy);
				cout << m_strWord;
			}
			else
			{
				m_Tool.gotoxy(m_ix + length, m_iy);
				cout << m_strWord.substr(length, m_strWord.size());
			}
			m_Tool.gotoxy(m_ix, m_iy - 1);
			if (m_iy == ROOF_START)
			{
				m_Tool.gotoxy(m_ix, m_iy - 1);
				for (int i = 0; i < m_strWord.size(); i++)
					cout << " ";
				return;
			}
			m_Tool.gotoxy(m_ix+ length, m_iy - 1);
			for (int i = length; i <= m_strWord.size(); i++)
				cout << " ";
			return;
		}
	}
	if (!(m_iy == MAP_HEIGHT - 1))
	{
		m_Tool.gotoxy(m_ix, m_iy);
		cout << m_strWord;
	}
	if(m_iy == 1)
	{
		return;
	}
	m_Tool.gotoxy(m_ix, m_iy-1);
	for (int i = 0; i < m_strWord.size(); i++)
		cout << " ";
	ORIGINAL
}
void Ward::Hidden()
{
	if (m_iy == 1)
		m_Tool.gotoxy(m_ix, m_iy);
	else
		m_Tool.gotoxy(m_ix, m_iy-1);
	for (int i = 0; i < m_strWord.size(); i++)
		cout << " ";
}
Ward::~Ward()
{

}