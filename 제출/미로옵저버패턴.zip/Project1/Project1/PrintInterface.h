#pragma once
#include"Subject.h"
#include"Observer.h"
#include<vector>
using namespace std;

class PrintInterface : public Subject
{
private:
	vector<Observer*>observerList;
	int m_iIndex;
public:
	virtual void NotifyObserver();
	virtual void AddObserver(Observer* input);
	void UpdateIndex(int _num);
	PrintInterface();
	~PrintInterface();
};

