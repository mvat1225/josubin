#pragma once
#include"Gamemanager.h"
class Game
{
private:
	Gamemanager* m_Game;
public:
	virtual void Init();
	virtual void Update();
	virtual void Finished();
protected:
	virtual Gamemanager* CreateGame() = 0;
};

class Miro : public Game
{
protected:
	virtual Gamemanager* CreateGame();
};