#include"Game.h"

void main()
{
	Game* MiroGame = new Miro();
	MiroGame->Init();
	MiroGame->Update();
	MiroGame->Finished();
}