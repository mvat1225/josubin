#pragma once
#include"Observer.h"
class InGameHint : public Observer
{
private:
	HINTPRINT m_eHint;
	void Print();
	bool m_bToolHave;/////////////////////////////////�̰��ּ��ϱ�?
public:
	void gotoxy(int x, int y)

	{

		COORD pos = { x,y };

		SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), pos);

	}
	inline void GetHammer() { m_bToolHave = true; };
	virtual void Update(int Num);
	InGameHint();
	~InGameHint();
};

