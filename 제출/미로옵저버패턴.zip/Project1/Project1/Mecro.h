#pragma once
#include<stdio.h>
#include<conio.h>
#include<Windows.h>
#include<string.h>
#include<vector>
#define SAME 0
#define DIFFERENT 1
#define WALL 1
#define NULL 0
#define CHARACTER 2
#define HOLE 10
#define QUESTION_START 20
#define QUESTION_MAX 5//20��
#define SAND_START 40
#define SAND_MAX 4//40�� �� 44��°�� ���� �𷡾ƴ�
#define Y 0
#define X 1
#define TIP 50
#define TIP1 51
#define PASSWORDDOOR 4
#define HINT 50
#define DOORHINT 56//��й� ��Ʈ
#define LEFT 'a'
#define RIGHT 'd'
#define UP 'w'
#define DOWN 's'
#define WEIGHT 13
#define HIGHT 14
#define EXIT 6
#define CHEST 44
#define FALSE 0
#define TIP 1
#define TIP_2 2
#define TIP_3 3
#define TIP_4 4
#define TIP_5 5
#define TIP_6 6
#define OPENDOOR 5
#define ROCK 100
#define MIDDLEROCK 85
#define ROCK_DEL 75

enum QUIZ {
	QUIZ_FPS = 20,
	QUIZ_GAME,
	QUIZ_CHAMPION,
	QUIZ_CORRECT,
	QUIZ_SERIZE
};
enum HINTPRINT {
	HINTPRINT_SOIL = 50,
	HINTPRINT_LOCKDOOR,
	HINTPRINT_PASSWORD,
	HINTPRINT_GETHAMMER,
	HINTPRINT_NEEDSOMETHING,
	HINTPRINT_BREAK
};