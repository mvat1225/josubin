#include "PrintInterface.h"



PrintInterface::PrintInterface()
{
}
void PrintInterface::AddObserver(Observer* input)
{
	observerList.push_back(input);
}
void PrintInterface::NotifyObserver()
{
	for (auto iter = observerList.begin(); iter != observerList.end(); iter++)
	{
		(*iter)->Update(m_iIndex);
	}
}
void PrintInterface::UpdateIndex(int _num)
{
	m_iIndex = _num;
	NotifyObserver();
}

PrintInterface::~PrintInterface()
{
}
