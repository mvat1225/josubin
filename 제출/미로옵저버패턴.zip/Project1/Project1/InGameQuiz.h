#pragma once
#include"Observer.h"
#include"Mecro.h"
using namespace std;
class InGameQuiz :public Observer
{
private:
	QUIZ m_eQuiz;
	void  Print();
public:
	void gotoxy(int x, int y)
	{

		COORD pos = { x,y };

		SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), pos);

	}
	virtual void Update(int Num);
	InGameQuiz();
	~InGameQuiz();
};

