#pragma once
#include"Mecro.h"
#include<vector>
class Observer
{
public:
	virtual void Update(int Num) = 0;
	Observer();
	~Observer();

};
