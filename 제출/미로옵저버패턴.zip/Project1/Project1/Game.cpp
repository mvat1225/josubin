#include "Game.h"
void Game::Init()
{
	m_Game = CreateGame();
}

void Game::Update()
{
	m_Game->Render();
}
void Game::Finished()
{
	m_Game->End();
}

Gamemanager* Miro::CreateGame()
{
	return Gamemanager::GetInstance();
}