#include "Gamemanager.h"
Gamemanager* Gamemanager::m_pThis = NULL;
Gamemanager::Gamemanager()
{



	m_InterfaceAlarm->AddObserver(m_InGameHint);
	m_InterfaceAlarm->AddObserver(m_InGameQuiz);




	m_bGameEnd = false;
	m_bGameClear = false;
	m_bPasswordKnow = false;
	sworld = FALSE;
	Lastindex = NULL;
	m_Player.m_iSoilCount = 0;
	for (int y = 0; y < HIGHT; y++)
	{
		for (int x = 0; x < WEIGHT; x++)
		{
			if (m_Map[y][x] == CHARACTER)
			{
				m_Player.Character[Y] = y;
				m_Player.Character[X] = x;
			}
			else if (m_Map[y][x] >= QUESTION_START && m_Map[y][x] < (QUESTION_START + QUESTION_MAX))
			{
				Question[m_Map[y][x] - QUESTION_START][Y] = y;
				Question[m_Map[y][x] - QUESTION_START][X] = x;
			}
			else if (m_Map[y][x] == HOLE)
			{
				Hole[Y] = y;
				Hole[X] = x;
			}
			else if (m_Map[y][x] >= SAND_START && m_Map[y][x] < (SAND_START + SAND_MAX))
			{
				Sand[m_Map[y][x] - SAND_START][Y] = y;
				Sand[m_Map[y][x] - SAND_START][X] = x;
			}
		}
	}
	MainMenu();
}
void Gamemanager::MapClear()
{
	for (int y = 0; y < 9; y++)
	{
		for (int x = 0; x < WEIGHT*2; x++)
		{
			gotoxy(x, y);
			cout << "  ";
		}
	}
	gotoxy(0, 0);
}
void Gamemanager::Render()
{
	system("cls");
	while (!m_bGameEnd && !m_bGameClear)
	{
		MapDraw();
		Move();
	}
}
void Gamemanager::End()
{
	if (m_bGameClear)
	{
		GameClearPrint();
	}
	else
		GameOverPrint();
}
void Gamemanager::GameOverPrint()
{
	system("cls");
	printf("====================\n");
	printf("l     ���ӿ���     l\n");
	printf("====================\n");
	system("pause");
}
void Gamemanager::MainMenu()
{
	printf("=======================\n");
	printf("l                     l\n");
	printf("l   ���߾� �̷�ã��   l\n");
	printf("l                     l\n");
	printf("l   1.����            l\n");
	printf("l                     l\n");
	printf("l   2.����            l\n");
	printf("l                     l\n");
	printf("=======================\n");
	printf("���� : \n�� = �����Դϴ�. ������ ������ ���̳��ϴ�.\n");
	printf("�� = �����Դϴ�. ����� ������ ������ �ʽ��ϴ�.\n");
	printf("�� = ��й�ȣ�� �ʿ��� ���Դϴ�.\n");
	printf("�� = ���Դϴ�. ������ �޲ٴµ� ���Դϴ�.\n");
	printf("�� = �ⱸ�Դϴ�. �̰��� ���� ������ Ŭ�����ϰ� �˴ϴ�.\n");
	printf("�� = �����Դϴ�. ���⸦ ȹ���� �� �ֽ��ϴ�.\n");
	scanf("%d", &m_iMenuSelect);
}

void Gamemanager::GameClearPrint()
{
	system("cls");
	printf("=================================\n");
	printf("l                               l\n");
	printf("l    ��                   ��    l\n");
	printf("l                               l\n");
	printf("l            CLEAR!!!           l\n");
	printf("l                               l\n");
	printf("=================================\n");
	system("pause");
}

void Gamemanager::Move()
{

	char ch;
	ch = getch();
	m_Map[m_Player.Character[Y]][m_Player.Character[X]] = Lastindex;
	switch (ch)
	{
	case LEFT:
		if (m_Map[m_Player.Character[Y]][m_Player.Character[X] - 1] == HOLE && m_Player.m_iSoilCount != 0)
		{
			m_Map[m_Player.Character[Y]][m_Player.Character[X] - 1] -= 10;
			m_Player.m_iSoilCount--;
			break;
		}
		else if (m_Map[m_Player.Character[Y]][m_Player.Character[X] - 1] != WALL)
		{
			m_Player.Character[X]--;
			break;
		}
		break;
	case RIGHT:
		if (m_Map[m_Player.Character[Y]][m_Player.Character[X] + 1] == HOLE && m_Player.m_iSoilCount != 0)
		{
			m_Map[m_Player.Character[Y]][m_Player.Character[X] + 1] -= 10;
			m_Player.m_iSoilCount--;
			break;
		}
		else if (m_Map[m_Player.Character[Y]][m_Player.Character[X] + 1] != WALL)
		{
			m_Player.Character[X]++;
			break;
		}
		break;
	case DOWN:
	if (m_Map[m_Player.Character[Y] + 1][m_Player.Character[X]] == HOLE && m_Player.m_iSoilCount != 0)
		{
			m_Map[m_Player.Character[Y] + 1][m_Player.Character[X]] -= 10;
			m_Player.m_iSoilCount--;
			break;
		}
		else if (m_Map[m_Player.Character[Y] + 1][m_Player.Character[X]] == ROCK && sworld == FALSE)
		{
			break;
		}
		else if (m_Map[m_Player.Character[Y] + 1][m_Player.Character[X]] <= ROCK && sworld == TRUE && m_Map[m_Player.Character[Y] + 1][m_Player.Character[X]] > ROCK_DEL)
		{
			m_Map[m_Player.Character[Y] + 1][m_Player.Character[X]] -= 1;
			if (m_Map[m_Player.Character[Y] + 1][m_Player.Character[X]] == ROCK_DEL)
			{
				m_Map[m_Player.Character[Y] + 1][m_Player.Character[X]] = 0;
			}
		}
		else if (m_Map[m_Player.Character[Y] + 1][m_Player.Character[X]] != WALL)
		{
			m_Player.Character[Y]++;
		}
		if (m_Map[m_Player.Character[Y]][m_Player.Character[X]] == PASSWORDDOOR)
		{
			if (!m_bPasswordKnow)
			{
				m_Player.Character[Y]--;
				break;
			}
			char password[10];
			char ch[10] = "0000";
			system("cls");
			printf("   \n\n��й�ȣ�� �Է��Ͻÿ� :");
			scanf("%s", password);
			if (strcmp(password, ch) == SAME)
			{
				m_Map[m_Player.Character[Y]][m_Player.Character[X]] = OPENDOOR;
				system("cls");
				break;
			}
			else
			{
				m_bGameEnd = true;
				return;
			}
		}
		break;
	case UP:
		if (m_Map[m_Player.Character[Y] - 1][m_Player.Character[X]] == HOLE && m_Player.m_iSoilCount != 0)
		{
			m_Map[m_Player.Character[Y] - 1][m_Player.Character[X]] -= 10;
			m_Player.m_iSoilCount--;
			break;
		}
		else if (m_Map[m_Player.Character[Y] - 1][m_Player.Character[X]] != WALL)
		{
			m_Player.Character[Y]--;
			break;
		}
	}
	Movecheck();
	Lastindex = m_Map[m_Player.Character[Y]][m_Player.Character[X]];
	m_Map[m_Player.Character[Y]][m_Player.Character[X]] = CHARACTER;
	MapClear();
}
void Gamemanager::Movecheck()
{
	int index = m_Map[m_Player.Character[Y]][m_Player.Character[X]];
	if (index == 54 && sworld == TRUE)
	{
		m_Map[m_Player.Character[Y]][m_Player.Character[X]] = 53;
	}
	m_InterfaceAlarm->UpdateIndex(index);
	if (index == 52)
	{
		m_bPasswordKnow = TRUE;
	}
	else if (index == HOLE && m_Player.m_iSoilCount == 0)
	{
		m_bGameEnd = true;
	}
	else if (index >= QUESTION_START && index < QUESTION_START + QUESTION_MAX)
	{
		Quiz(index);
	}
	else if (index >= SAND_START && index < SAND_MAX + SAND_START)
	{
		m_Player.m_iSoilCount++;
		m_Map[m_Player.Character[Y]][m_Player.Character[X]] = 0;
	}
	else if (index == 44)
	{
		sworld = TRUE;
		m_InGameHint->GetHammer();
		m_Map[m_Player.Character[Y]][m_Player.Character[X]] = 0;
	}
	if (index == EXIT)
	{
		m_bGameClear = true;
		m_bGameEnd = true;
		return;
	}
}
void Gamemanager::Quiz(int index)//���������� ���
{
	/*int index = m_Map[Character[Y]][Character[X]];*/
	int answer;
	if (index == 20)
	{
		std::cin >> answer;
		if (answer != 3)
		{
			m_bGameEnd = true;
			return;
		}
	}
	else if (index == 21)
	{
		answer = 0;
		std::cin >> answer;
		if (answer != 4)
		{
			m_bGameEnd = true;
			return;
		}
	}
	else if (index == 22)
	{
		answer = 0;
		std::cin >> answer;
		if (answer != 4)
		{
			m_bGameEnd = true;
			return;
		}
	}
	else if (index == 23)
	{
		answer = 0;
		std::cin >> answer;
		if (answer != 4)
		{
			m_bGameEnd = true;
			return;
		}
	}
	else if (index == 24)
	{
		answer = 0;
		std::cin >> answer;
		if (answer != 5)
		{
			m_bGameEnd = true;
			return;
		}
	}
	m_Map[m_Player.Character[Y]][m_Player.Character[X]] = NULL;
	system("cls");
}
void Gamemanager::MapDraw()
{
	for (int y = 0; y < 10; y++)
	{
		for (int x = 0; x < WEIGHT; x++)
		{
			if (m_Map[y][x] == 1)
			{
				printf("��");
			}
			else if (m_Map[y][x] == HOLE)
			{
				printf("��");
			}
			else if (m_Map[y][x] >= SAND_START && m_Map[y][x] < SAND_START + SAND_MAX)
			{
				printf("��");
			}
			else if (m_Map[y][x] >= QUESTION_START && m_Map[y][x] < QUESTION_START + QUESTION_MAX)
			{
				printf("��");
			}
			else if (m_Map[y][x] == EXIT)
			{
				printf("��");
			}
			else if (m_Map[y][x] == PASSWORDDOOR)
			{
				printf("��");
			}
			else if (m_Map[y][x] == CHARACTER)
			{
				printf("��");
			}
			else if (m_Map[y][x] == CHEST)
			{
				printf("��");
			}
			else if (m_Map[y][x] == OPENDOOR)
			{
				printf("��");
			}
			else if (m_Map[y][x] <= ROCK && m_Map[y][x] > MIDDLEROCK)
			{
				printf("��");
			}
			else if (m_Map[y][x] >= ROCK_DEL && m_Map[y][x] <= MIDDLEROCK)
			{
				printf("��");
			}
			else
			{
				printf("  ");
			}
		}
		printf("\n");
	}
	printf("�� ���� ���� : %d\n", m_Player.m_iSoilCount);
	printf("��Ʈ :");
}
Gamemanager::~Gamemanager()
{

}