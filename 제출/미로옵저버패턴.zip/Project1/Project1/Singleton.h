#pragma once

template<typename T>
class Singleton
{
private:
	static T* m_pThis;
public:
	Singleton() {};
	virtual ~Singleton() {};
	static T* GetInstance()
	{
		if (m_pThis == NULL)
			m_pThis = new T;
		return m_pThis;
	}
	static void RemoveInstance()
	{
		if (m_pThis)
		{
			delete m_pThis;
			m_pThis = NULL;
		}
	}
};

