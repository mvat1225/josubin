#pragma once
#include<iostream>
#include"Mecro.h"
#include"Singleton.h"
#include"InGameHint.h"
#include"InGameQuiz.h"
#include"PrintInterface.h"
struct Player
{
	int m_iSoilCount;
	int Character[2];
};
class Gamemanager : public Singleton<Gamemanager>
{
private:




	PrintInterface* m_InterfaceAlarm = new PrintInterface;
	InGameHint* m_InGameHint = new InGameHint;
	InGameQuiz* m_InGameQuiz = new InGameQuiz;




	void MapClear();
	bool m_bGameEnd;
	bool m_bGameClear;
	Player m_Player;
	int Hole[2];
	int Question[QUESTION_MAX][4];
	int Sand[SAND_MAX][2];
	bool m_bPasswordKnow;
	int sworld;
	int Lastindex;
	int m_iMenuSelect;
	int m_Map[WEIGHT][HIGHT] = {
		{1,1,1,1,1,1,1,1,1,1,1,1,1},
		{1,2,20,40,1,52,0,0,0,0,0,0,1},
		{1,50,1,1,0,0,0,0,0,0,0,51,1},
		{1,10,1,0,0,1,1,1,1,1,1,4,1},
		{1,0,0,0,1,43,1,42,1,41,1,0,1},
		{1,1,1,1,1,23,1,22,1,21,1,0,1},
		{1,54,0,0,10,50,10,50,10,50,0,0,1},
		{1,100,1,0,1,1,1,1,1,1,1,1,1},
		{1,6,1,0,0,24,44,1,1,1,1,1,1},
		{1,1,1,1,1,1,1,1,1,1,1,1,1} };
public:
	void gotoxy(int x, int y)
	{
		COORD pos = { x,y };
		SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), pos);
	}
	Gamemanager();
	~Gamemanager();
	void GameOverPrint();
	void GameClearPrint();
	void MainMenu();
	void Render();
	void End();
	void Move();
	void Movecheck();
	void MapDraw();
	void Quiz(int index);
};

