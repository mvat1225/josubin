#pragma once
#include"BitMap.h"
#include"BitmapManager.h"
enum CARDSTATE
{
	CARDSTATE_FRONT,
	CARDSTATE_BACK,
	CARDSTATE_END
};
class Card
{
private:
	int m_iHealth;
	BitMap* m_pBitMap[CARDSTATE_END];
	CARDSTATE m_eCardState;
	int m_ix;
	int m_iy;
	RECT m_BitMapRect;
	IMAGE m_eCard_Index;
public:
	Card();
	inline CARDSTATE GetState() { return m_eCardState; };
	inline int GetCardIndex() { return (int)m_eCard_Index; };
	void ChangeState(HDC hdc, CARDSTATE state);
	void Init(IMAGE index, int PrintStartPosition_x, int PrintStartPosition_y);
	void Draw(HDC hdc);
	int ColiderCheck(const POINT& point, HDC hdc);
	~Card();

};

