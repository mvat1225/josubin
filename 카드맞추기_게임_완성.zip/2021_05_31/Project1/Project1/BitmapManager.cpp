#include "BitmapManager.h"

BitmapManager* BitmapManager::m_pThis = NULL;

BitmapManager::BitmapManager()
{
	m_pBitMap = new BitMap[IMAGE_END];
}

void BitmapManager::Init(HDC hdc)
{
	char buf[256];
	for (int i = IMAGE_START; i < IMAGE_END ; i++)
	{
		sprintf(buf, "RES//%d.bmp", i);
		m_pBitMap[i].Init(hdc, buf);
	}
}
void BitmapManager::DrawBackGround(HDC hdc)
{
	m_pBitMap[IMAGE_BACKGROUND].Draw_BackGround(hdc);
}
BitmapManager::~BitmapManager()
{
	delete[] m_pBitMap;
}