#include "Card.h"

Card::Card()
{
	m_iHealth = 2;
}

void Card::Init(IMAGE index, int PrintStartPosition_x, int PrintStartPosition_y)
{
	SIZE size_tmp;
	m_eCard_Index = index;
	m_eCardState = CARDSTATE_BACK; //////////////////////////
	m_pBitMap[CARDSTATE_FRONT] = BitmapManager::GetInstance()->GetImage(index);
	m_pBitMap[CARDSTATE_BACK] = BitmapManager::GetInstance()->GetImage(IMAGE_BLACK);
	m_ix = PrintStartPosition_x;
	m_iy = PrintStartPosition_y;
	m_BitMapRect.left = m_ix;
	m_BitMapRect.top = m_iy;
	m_BitMapRect.right = (m_BitMapRect.left + m_pBitMap[CARDSTATE_FRONT]->GetSize().cx * 0.5);
	m_BitMapRect.bottom = (m_BitMapRect.top + m_pBitMap[CARDSTATE_FRONT]->GetSize().cy * 0.5);
}
int Card::ColiderCheck(const POINT& point,HDC hdc)
{
	if (PtInRect(&m_BitMapRect, point))
	{
		m_eCardState = CARDSTATE_FRONT;
		Draw(hdc);
		return m_eCard_Index;
	}
	return -1;
}
void Card::ChangeState(HDC hdc,CARDSTATE state)
{
	m_eCardState = state;
	if(state != CARDSTATE_END)
		Draw(hdc);
	/////////////////////////////////////////////////////////////////////////
}
void Card::Draw(HDC hdc)
{
	m_pBitMap[m_eCardState]->Draw_CardSize(hdc, m_ix,m_iy);
}

Card::~Card()
{

}