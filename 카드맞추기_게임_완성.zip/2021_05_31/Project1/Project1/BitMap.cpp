#include "BitMap.h"


BitMap::BitMap()
{

}

void BitMap::Init(HDC hdc,char* FileName)
{
	MemDC = CreateCompatibleDC(hdc);
	m_BitMap = (HBITMAP)LoadImageA(NULL, FileName, IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE | LR_CREATEDIBSECTION);
	m_OldMitMap = (HBITMAP)SelectObject(MemDC, m_BitMap);
	BITMAP BitMap_Info;
	GetObject(m_BitMap, sizeof(BitMap_Info), &BitMap_Info);
	m_Size.cx = BitMap_Info.bmWidth;
	m_Size.cy = BitMap_Info.bmHeight;
}
void BitMap::Draw_BackGround(HDC hdc)
{
	StretchBlt(hdc, 0, 0, m_Size.cx+ BACKGROUND_PLUS_X, m_Size.cy+ BACKGROUND_PLUS_Y, MemDC, 0, 0, m_Size.cx, m_Size.cy, SRCCOPY);
}
void BitMap::Draw_CardSize(HDC hdc, int x, int y)
{
	StretchBlt(hdc, x, y, m_Size.cx*0.5, m_Size.cy*0.5, MemDC, 0, 0, m_Size.cx, m_Size.cy, SRCCOPY);
}
BitMap::~BitMap()
{
	SelectObject(MemDC, m_OldMitMap);
	DeleteObject(m_BitMap);
	DeleteDC(MemDC);
}