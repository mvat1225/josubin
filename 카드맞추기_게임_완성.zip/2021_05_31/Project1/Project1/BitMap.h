#pragma once
#include"Mecro.h"
class BitMap
{
private:
	HDC MemDC;
	HBITMAP m_BitMap;
	HBITMAP m_OldMitMap;
	SIZE m_Size;
public:
	void Init(HDC hdc, char* FileName);
	void Draw_CardSize(HDC hdc, int x, int y);
	void Draw_BackGround(HDC hdc);
	inline SIZE GetSize()
	{
		return m_Size;
	}
	BitMap();
	~BitMap();
};

