#pragma once
#include"BitMap.h"
enum IMAGE
{
	IMAGE_START = 0,
	IMAGE_DOG = 0,
	IMAGE_TIGER,
	IMAGE_DUCK,
	IMAGE_ELEPHANT,
	IMAGE_COW,
	IMAGE_HORSE,
	IMAGE_CAT,
	IMAGE_MONKEY,
	IMAGE_FROG,
	IMAGE_CHICKEN,
	IMAGE_BLACK,
	IMAGE_BACKGROUND,
	IMAGE_END,
	IMAGE_CARD_END = 10
};
class BitmapManager
{
private:
	static BitmapManager* m_pThis;
	BitMap* m_pBitMap; 
public:
	static BitmapManager* GetInstance()
	{
		if (m_pThis == NULL)
			m_pThis = new BitmapManager;
		return m_pThis;
	}
	inline SIZE GetBitMapSize(IMAGE index)
	{
		SIZE size = m_pBitMap[index].GetSize();
		return size;
	}
	inline BitMap* GetImage(IMAGE index)
	{
		return &m_pBitMap[index];
	}
	void Init(HDC hdc);
	void DrawBackGround(HDC hdc);
	BitmapManager();
	~BitmapManager();
	
};

