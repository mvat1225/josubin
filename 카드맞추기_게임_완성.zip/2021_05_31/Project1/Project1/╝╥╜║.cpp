#include<Windows.h>
#include<string.h>
#include<stdlib.h>
#include<stdio.h>
#include<time.h>
#include"Gamemanager.h"
LRESULT CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);
HINSTANCE g_hInst;
LPCTSTR lpszClass = TEXT("CARD_GAME");
HDC hdc;

int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE hPervlnstance, LPSTR lpszCmdParam, int nCmdShow)
{
	HWND hWnd;
	WNDCLASS WndClass;
	g_hInst = hInstance;
	srand(time(NULL));
	WndClass.cbClsExtra = 0;
	WndClass.cbWndExtra = 0;
	WndClass.hbrBackground = (HBRUSH)GetStockObject(WHITE_BRUSH);	//����
	WndClass.hCursor = LoadCursor(NULL, IDC_ARROW);	//Ŀ��
	WndClass.hIcon = LoadIcon(NULL, IDI_APPLICATION);	//������ ���
	WndClass.hInstance = hInstance;
	WndClass.lpfnWndProc = WndProc;	//���μ��� �Լ� ȣ��
	WndClass.lpszClassName = lpszClass;	//Ŭ���� �̸�
	WndClass.lpszMenuName = NULL;
	WndClass.style = CS_HREDRAW | CS_VREDRAW;
	RegisterClass(&WndClass);
	hWnd = CreateWindow(lpszClass, lpszClass, WS_CAPTION | WS_SYSMENU | WS_MINIMIZEBOX, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT,
		NULL, (HMENU)NULL, hInstance, NULL);
	//static Gamemanager GM(hWnd);
	hdc = GetDC(hWnd);
	Gamemanager::GetInstance()->Init(hWnd);
	SIZE BG_Size = Gamemanager::GetInstance()->Get_BG_Size(IMAGE_BACKGROUND);
	SetWindowPos(hWnd, NULL, 50, 50, BG_Size.cx + BACKGROUND_PLUS_X, BG_Size.cy + BACKGROUND_PLUS_Y, 0);
	ShowWindow(hWnd, nCmdShow);
	//Gamemanager::GetInstance()->DrawBackGround();
	//Gamemanager::GetInstance()->DrawCard();
	MSG Message;
	ZeroMemory(&Message, sizeof(Message));
	while (WM_QUIT != Message.message)
	{
		if (PeekMessage(&Message, NULL, 0, 0, PM_REMOVE))
		{
			TranslateMessage(&Message);
			DispatchMessage(&Message);
		}
		else if (Gamemanager::GetInstance()->GameClear())
		{
			MessageBox(hWnd, "���� Ŭ����", "Ȯ��", MB_OK);
			PostQuitMessage(0);
		}
		else
		{
			Gamemanager::GetInstance()->TurnCardOverBack();
		}
	}

	ReleaseDC(hWnd, hdc);
	return (int)Message.wParam;
}

LRESULT CALLBACK WndProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{	
	POINT MousePoint;
	switch (iMessage)
	{
	case WM_LBUTTONDOWN:
		MousePoint.x = LOWORD(lParam);
		MousePoint.y = HIWORD(lParam);
		Gamemanager::GetInstance()->ColisionCheck(MousePoint);
		break;
	case WM_PAINT:
	{
		PAINTSTRUCT ps;
		HDC hdc = BeginPaint(hWnd, &ps);
		Gamemanager::GetInstance()->DrawBackGround();
		Gamemanager::GetInstance()->DrawCard();
		//��� �׸��� �ϱ� Gamemanager::GetInstance()->DrawBackGround(hdc);
		//InvalidateRect(hWnd,NULL,true); 3���� ���ڰ� false = ��ü �� ������� �׳� ���,
		//InvalidateRect(hWnd, NULL, false);
		EndPaint(hWnd, &ps);
	}
		break;
	case WM_DESTROY:
		PostQuitMessage(0);
		return 0;
	}
	return(DefWindowProc(hWnd, iMessage, wParam, lParam));
}