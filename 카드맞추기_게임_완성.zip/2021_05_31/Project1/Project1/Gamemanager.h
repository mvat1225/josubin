#pragma once
#include"Card.h"

class Gamemanager
{
private:
	int m_iCorrectCardCount;
	LONGLONG m_iNowClock;
	LONGLONG m_iNewClock;
	HDC m_hdc;
	int SameCheck_1 = -1;
	int SameCheck_2 = -1;
	const int m_iSpace = 6;
	static Gamemanager* m_pThis;
	Card Card_List[20];
	int Check[IMAGE_CARD_END] = { 2,2,2,2,2,2,2,2,2,2 };
public:
	static Gamemanager* GetInstance()
	{
		if (m_pThis == NULL)
			m_pThis = new Gamemanager;
		return m_pThis;
	}
	SIZE Get_BG_Size(IMAGE index)
	{
		SIZE size = BitmapManager::GetInstance()->GetBitMapSize(index);
		return size;
	}

	Gamemanager();
	~Gamemanager();
	inline bool GameClear()
	{
		if (m_iCorrectCardCount == 10)
			return true;
		else
			return false;
	}
	void TurnCardOverBack();//ī�带 �˰� �ٽ� ������ �Լ�
	void DrawCard();
	int GetPrintStartPosition(float pivot, int a, int space, SIZE tmp,int Type);
	void Init(HWND hwnd);
	void CardSetting();
	void DrawBackGround();
	void ColisionCheck(const POINT& p);
};
