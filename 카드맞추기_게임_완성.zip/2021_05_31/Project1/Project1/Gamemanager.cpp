#include "Gamemanager.h"

Gamemanager* Gamemanager::m_pThis = NULL;

Gamemanager::Gamemanager()
{
    m_iCorrectCardCount = 0;
}
void Gamemanager::CardSetting()
{

    SIZE tmp = BitmapManager::GetInstance()->GetBitMapSize(IMAGE_DOG);
    tmp.cx *= 0.5f;
    tmp.cy *= 0.5f;

    SIZE back = BitmapManager::GetInstance()->GetBitMapSize(IMAGE_BACKGROUND);
    back.cx += 50;
    back.cy += 100;

    int Min_x = GetPrintStartPosition(back.cx * 0.5f, (int)COLUMNS, m_iSpace, tmp, X);
    int Min_y = GetPrintStartPosition(back.cy * 0.5f, (int)ROWS, m_iSpace, tmp, Y);
    int Save_X = Min_x;

    int Rand;
    int Count = (int)COLUMNS;
    for (int i = 0; i < (IMAGE_CARD_END) * 2; i++)
    {
        
        while (1)
        {
            Rand = rand() % (IMAGE_CARD_END);
            if (Check[Rand] > 0)
            {
                Check[Rand]--;
                break;
            }
        }
        Card_List[i].Init((IMAGE)Rand, Min_x, Min_y);
        if (Count == 1)
        {
            Min_x = Save_X;
            Min_y += tmp.cy + m_iSpace;

            Count = (int)COLUMNS;
        }
        else
        {
            Min_x += m_iSpace + tmp.cx;
            Count--;
        }
    }
}
void Gamemanager::DrawCard()
{
    for (int i = 0; i < IMAGE_CARD_END * 2; i++)
    {
        Card_List[i].Draw(m_hdc);
    }
}
int Gamemanager::GetPrintStartPosition(float pivot, int a, int space, SIZE tmp, int Type)
{
    int Length;
    if (Type == X)
        Length = ((tmp.cx * a) + (space * (a - 1))) * 0.5f;
    else
        Length = ((tmp.cy * a) + (space * (a - 1))) * 0.5f;
    return (int)pivot - Length;
}

void Gamemanager::TurnCardOverBack()
{
    if (SameCheck_1 >= 0 || SameCheck_2 >= 0)
    {
        m_iNewClock = GetTickCount64();
        if (m_iNewClock - m_iNowClock >= 2000)
        {
            if (SameCheck_1 >= 0)
                Card_List[SameCheck_1].ChangeState(m_hdc, CARDSTATE_BACK);
            if (SameCheck_2 >= 0)
                Card_List[SameCheck_2].ChangeState(m_hdc, CARDSTATE_BACK);
            SameCheck_1 = -1;
            SameCheck_2 = -1;
        }
    }
}
void Gamemanager::ColisionCheck(const POINT& p)
{
    if (0 > SameCheck_2)
    {
        int Check;
        for (int i = IMAGE_START; i < IMAGE_CARD_END * 2; i++)
        {
            Check = i;
            if (0 <= (Card_List[i].ColiderCheck(p, m_hdc)) && Card_List[i].GetState() != CARDSTATE_END)//Ŭ���� ��ǥ�� �ش� ī�尡 ���� ��
            {
                m_iNowClock = GetTickCount64();
                if (0 <= SameCheck_1)//�� �� ���� ��� ������
                {
                    if (Card_List[SameCheck_1].GetCardIndex() == Card_List[Check].GetCardIndex())//�� �� ���� �� �� �� ���̰� ���ٸ�
                    {
                        Card_List[Check].ChangeState(m_hdc, CARDSTATE_END);
                        Card_List[SameCheck_1].ChangeState(m_hdc, CARDSTATE_END);
                        m_iCorrectCardCount++;
                        SameCheck_1 = -1;
                    }
                    else
                    {
                        SameCheck_2 = Check;
                    }
                }
                else
                {
                    SameCheck_1 = Check;
                }
            }
        }
    }
}
void Gamemanager::Init(HWND hwnd)
{
    m_hdc = GetDC(hwnd);
    BitmapManager::GetInstance()->Init(m_hdc);
    CardSetting();
}

void Gamemanager::DrawBackGround()
{
    BitmapManager::GetInstance()->DrawBackGround(m_hdc);
}

Gamemanager::~Gamemanager()
{

}