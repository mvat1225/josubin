#pragma once
#include<stdlib.h>

#include<stdio.h>
#include<Windows.h>
#include<time.h>
#define BACKGROUND_PLUS_X 50
#define BACKGROUND_PLUS_Y 100
#define ROWS 4
#define COLUMNS 5
#define X 1
#define Y 0