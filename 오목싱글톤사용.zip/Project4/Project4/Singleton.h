#pragma once
template<typename T>
class Singleton
{
private:
	static T* m_pSigneton;
public:
	static T* GetInstance()
	{
		if (m_pSigneton == NULL)
			m_pSigneton = new T;
		else
			return m_pSigneton;
	}
	Singleton()
	{

	}
	~Singleton()
	{

	}
};
